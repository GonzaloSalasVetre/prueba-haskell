module Main where
import Criterion.Main

main :: IO ()
main = putStrLn "Hello, Haskell!"

